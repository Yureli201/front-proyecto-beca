import React from 'react';
// Importa el logo
import LogoProyecto from '../../src/logo-beca.png'; // <-- 1. IMPORTA TU LOGO

import 'bootstrap/dist/css/bootstrap.min.css';
import '../assets/App.css'; 

function LoginEstudiante() {
  return (
    <div className="vh-100 d-flex align-items-center justify-content-center bg-light p-4">
      <div className="card shadow-lg border-0 rounded-3" style={{ width: '100%', maxWidth: '400px' }}>
        <div className="card-body p-4 p-md-5 text-center">
          
          {/* Div que contiene el logo */}
          <div className="logo-box d-flex align-items-center justify-content-center rounded-3 mx-auto mb-4">
            
            {/* 2. USA EL LOGO EN UNA ETIQUETA <img> */}
            <img 
              src={LogoProyecto} 
              alt="Logo del Proyecto Beca" 
              className="logo-img" 
            />

          </div>

          <h1 className="h2 fw-bold text-dark mb-1">Bienvenido</h1>
          <p className="text-muted mb-4">Estimado estudiante</p>

          <form>
            {/* ... (el resto del formulario no cambia) ... */}
            <div className="form-group mb-3 text-start">
              <label htmlFor="usuario" className="form-label fw-semibold">
                Usuario
              </label>
              <input
                type="text"
                id="usuario"
                className="form-control form-control-lg bg-light"
              />
            </div>
            <div className="form-group mb-4 text-start">
              <label htmlFor="contrasena" className="form-label fw-semibold">
                Contraseña
              </label>
              <input
                type="password"
                id="contrasena"
                className="form-control form-control-lg bg-light"
              />
            </div>
            <button
              type="submit"
              className="btn btn-success btn-lg w-100 fw-bold mb-4"
            >
              Iniciar sesión
            </button>
            <a
              href="#"
              className="text-decoration-none text-muted"
            >
              Cambiar contraseña
            </a>
          </form>

        </div>
      </div>
    </div>
  );
}

export default LoginEstudiante;