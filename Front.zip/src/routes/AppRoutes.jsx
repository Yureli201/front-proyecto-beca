import React from 'react';
import { Routes, Route } from 'react-router-dom';

// 1. IMPORTA LOS NUEVOS COMPONENTES
import LoginEstudiante from '../features/LoginEstudiante';
import LoginAdmin from '../features/LoginAdmin';
import LoginCafeteria from '../features/LoginCafeteria';

export const AppRouter = () => {
  return (
    <Routes>
      {/* Rutas Públicas (Logins) */}
      
      {/* Ruta raíz, por defecto muestra el login de estudiante */}
      <Route path="/" element={<LoginEstudiante />} />
      
      {/* 2. AÑADE LAS RUTAS ESPECÍFICAS */}
      <Route path="/login-estudiante" element={<LoginEstudiante />} />
      <Route path="/login-admin" element={<LoginAdmin />} />
      <Route path="/login-cafeteria" element={<LoginCafeteria />} />

      {/* Aquí irán las rutas protegidas (Dashboards) */}
      {/* <Route path="/estudiante/dashboard" element={<EstudianteDashboard />} /> */}
      
    </Routes>
  );
};