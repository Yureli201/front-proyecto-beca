import React from 'react';
import { AppRouter } from './routes/AppRoutes.jsx'; // Importa tu cerebro

function App() {
  return (
    <AppRouter /> // Carga el cerebro
  );
}

export default App;